<?php 
$pageTitle = "Connexion - MediAssit";
require_once 'config.php';

// Redirection si déjà connecté
if (isLoggedIn()) {
    redirect('index.php');
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        
        // Mettre à jour la dernière connexion
        $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")
           ->execute([$user['id']]);
        
        redirect('index.php');
    } else {
        $error = "Identifiants incorrects";
    }
}

require_once 'header.php'; 
?>

<!-- Login Section -->
<section class="login_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="detail-box">
                    <h2>
                        Connectez-vous à <span>MediAssit</span>
                    </h2>
                    <p>
                        Accédez à votre espace personnel pour gérer vos rendez-vous, 
                        médicaments et ordonnances en toute simplicité.
                    </p>
                    <img src="images/slider-img.jpg" alt="MediAssit login" class="img-fluid">
                </div>
            </div>
            <div class="col-md-6">
                <div class="login-form">
                    <h4>Connexion</h4>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="password">Mot de passe</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        
                        <div class="btn-box">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-sign-in-alt"></i> Se connecter
                            </button>
                        </div>
                    </form>
                    
                    <div class="auth-links">
                        <a href="register.php" class="text-primary">
                            <i class="fas fa-user-plus"></i> Créer un compte
                        </a>
                        <a href="forgot-password.php" class="text-secondary">
                            <i class="fas fa-question-circle"></i> Mot de passe oublié ?
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>