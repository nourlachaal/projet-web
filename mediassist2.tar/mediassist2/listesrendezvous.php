<?php
// Set page title
$page_title = "Mes Rendez-vous - MediAssit";

// Include configuration and header
require_once 'config.php';
require_once 'header.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Récupérer les rendez-vous de l'utilisateur
try {
    $stmt = $pdo->prepare("SELECT * FROM rendezvous WHERE user_id = ? ORDER BY date_heure DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $rendezvous = $stmt->fetchAll();
} catch (PDOException $e) {
    $rendezvous = [];
    $error = "Erreur lors de la récupération des rendez-vous: " . $e->getMessage();
}
?>

<div class="container mt-5">
    <h2>Mes Rendez-vous</h2>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if (empty($rendezvous)): ?>
        <div class="alert alert-info">Vous n'avez aucun rendez-vous programmé.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>Type</th>
                        <th>Date/Heure</th>
                        <th>Lieu</th>
                        <th>Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rendezvous as $rdv): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($rdv['type_consultation']); ?></td>
                        <td><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($rdv['date_heure']))); ?></td>
                        <td><?php echo htmlspecialchars($rdv['lieu'] ?? 'Non spécifié'); ?></td>
                        <td><?php echo htmlspecialchars($rdv['notes'] ?? 'Aucune note'); ?></td>
                        <td>
                            <a href="modifierrendezvous.php?id=<?php echo $rdv['id']; ?>" class="btn btn-sm btn-warning">Modifier</a>
                            <a href="annulerrendezvous.php?id=<?php echo $rdv['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir annuler ce rendez-vous?')">Annuler</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    
    <div class="text-center mt-4">
        <a href="rendezvous.php" class="btn btn-primary">Prendre un nouveau rendez-vous</a>
    </div>
</div>

<?php
// Include footer
require_once 'footer.php';
?>