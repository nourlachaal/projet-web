<?php
// Set page title
$page_title = "Modifier Rendez-vous - MediAssit";

// Include configuration and header
require_once 'config.php';
require_once 'header.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Récupérer le rendez-vous à modifier
$rdv = null;
if (isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM rendezvous WHERE id = ? AND user_id = ?");
        $stmt->execute([$_GET['id'], $_SESSION['user_id']]);
        $rdv = $stmt->fetch();
        
        if (!$rdv) {
            $_SESSION['error'] = "Rendez-vous introuvable";
            header("Location: listesrendezvous.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur: " . $e->getMessage();
        header("Location: listesrendezvous.php");
        exit();
    }
}

// Traitement de la modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $typeConsultation = $_POST['type_consultation'];
    $dateHeure = $_POST['date_heure'];
    $lieu = $_POST['lieu'] ?? null;
    $notes = $_POST['notes'] ?? null;

try {
    $stmt = $pdo->prepare("UPDATE rendezvous 
                          SET type_consultation = ?, date_heure = ?, lieu = ?, notes = ?
                          WHERE id = ? AND user_id = ?");
    $stmt->execute([$typeConsultation, $dateHeure, $lieu, $notes, $_POST['id'], $_SESSION['user_id']]);
    
    $_SESSION['success'] = "Rendez-vous modifié avec succès!";
    $redirect_url = dirname($_SERVER['PHP_SELF']) . '/listesrendezvous.php';
    header("Location: " . $redirect_url);
    exit();
} catch (PDOException $e) {
    $error = "Erreur lors de la modification: " . $e->getMessage();
}}
?>

<div class="container mt-5">
    <h2>Modifier le Rendez-vous</h2>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if ($rdv): ?>
    <form action="modifierrendezvous.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $rdv['id']; ?>">
        
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="type_consultation">Type de consultation</label>
                <select class="form-control" id="type_consultation" name="type_consultation" required>
                    <option value="Consultation générale" <?php echo $rdv['type_consultation'] === 'Consultation générale' ? 'selected' : ''; ?>>Consultation générale</option>
                    <option value="Suivi de traitement" <?php echo $rdv['type_consultation'] === 'Suivi de traitement' ? 'selected' : ''; ?>>Suivi de traitement</option>
                    <option value="Urgence" <?php echo $rdv['type_consultation'] === 'Urgence' ? 'selected' : ''; ?>>Urgence</option>
                    <option value="Vaccination" <?php echo $rdv['type_consultation'] === 'Vaccination' ? 'selected' : ''; ?>>Vaccination</option>
                    <option value="Examen médical" <?php echo $rdv['type_consultation'] === 'Examen médical' ? 'selected' : ''; ?>>Examen médical</option>
                </select>
            </div>
            
            <div class="form-group col-md-6">
                <label for="date_heure">Date et heure</label>
                <input type="datetime-local" class="form-control" id="date_heure" name="date_heure" 
                       value="<?php echo date('Y-m-d\TH:i', strtotime($rdv['date_heure'])); ?>" required>
            </div>
        </div>
        
        <div class="form-group">
            <label for="lieu">Lieu</label>
            <input type="text" class="form-control" id="lieu" name="lieu" 
                   value="<?php echo htmlspecialchars($rdv['lieu']); ?>" placeholder="Adresse ou cabinet médical">
        </div>
        
        <div class="form-group">
            <label for="notes">Notes</label>
            <textarea class="form-control" id="notes" name="notes" rows="3"><?php echo htmlspecialchars($rdv['notes']); ?></textarea>
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
            <a href="listesrendezvous.php" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
    <?php endif; ?>
</div>

<?php
// Include footer
require_once 'footer.php';
?>