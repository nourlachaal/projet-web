<?php
// Set page title
$page_title = "Mes médicaments - MediAssit";

// Include configuration and header
require_once 'config.php';
require_once 'header.php';

// Verify user is logged in
if (!isLoggedIn()) {
    $_SESSION['error'] = "Vous devez vous connecter pour accéder à cette page";
    header("Location: login.php");
    exit();
}

// Handle flash messages
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Handle medication deletion
if (isset($_GET['delete_id'])) {
    $medicament_id = $_GET['delete_id'];
    
    // Verify medication exists and belongs to user
    $stmt = $pdo->prepare("SELECT id FROM medicaments WHERE id = ? AND user_id = ?");
    $stmt->execute([$medicament_id, $_SESSION['user_id']]);
    
    if ($stmt->fetch()) {
        try {
            $stmt = $pdo->prepare("DELETE FROM medicaments WHERE id = ?");
            $stmt->execute([$medicament_id]);
            $_SESSION['flash'] = "Médicament supprimé avec succès";
            header("Location: medicaments.php");
            exit();
        } catch (PDOException $e) {
            $error = "Erreur lors de la suppression: " . $e->getMessage();
        }
    } else {
        $error = "Médicament non trouvé ou vous n'avez pas les droits";
    }
}

// Fetch medications
try {
    $stmt = $pdo->prepare("SELECT * FROM medicaments WHERE user_id = ? ORDER BY prochaine_prise ASC");
    $stmt->execute([$_SESSION['user_id']]);
    $medicaments = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $error = "Une erreur est survenue lors du chargement des médicaments";
}
?>

<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="heading_container mb-4">
                    <h2><i class="fas fa-pills mr-2"></i> Mes médicaments</h2>
                    <a href="ajouter.php" class="btn btn-teal">
                        <i class="fas fa-plus"></i> Ajouter un médicament
                    </a>
                </div>

                <?php if (isset($flash)): ?>
                    <div class="alert alert-success">
                        <?= htmlspecialchars($flash) ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <?php if ($medicaments): ?>
                    <div class="card shadow-sm">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="bg-teal text-white">
                                        <tr>
                                            <th>Nom</th>
                                            <th>Posologie</th>
                                            <th>Fréquence</th>
                                            <th>Prochaine prise</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($medicaments as $med): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($med['nom']) ?></td>
                                                <td><?= htmlspecialchars($med['posologie']) ?></td>
                                                <td><?= ucfirst(htmlspecialchars($med['frequence'])) ?></td>
                                                <td><?= date('d/m/Y H:i', strtotime($med['prochaine_prise'])) ?></td>
                                                <td>
                                                    <div class="d-flex">
                                                        <a href="modifier.php?id=<?= $med['id'] ?>" class="btn btn-sm btn-outline-teal mr-2">
                                                            <i class="fas fa-edit"></i> Modifier
                                                        </a>
                                                        <a href="medicaments.php?delete_id=<?= $med['id'] ?>" class="btn btn-sm btn-danger" 
                                                           onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce médicament ?')">
                                                            <i class="fas fa-trash"></i> Supprimer
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="empty-state text-center py-5">
                        <i class="fas fa-pills fa-4x text-muted mb-4"></i>
                        <h4>Vous n'avez aucun médicament enregistré</h4>
                        <p class="text-muted mb-4">Commencez par ajouter votre premier médicament</p>
                        <a href="ajouter.php" class="btn btn-teal">
                            <i class="fas fa-plus"></i> Ajouter un médicament
                        </a>
                    </div>
                <?php endif; ?>

                <!-- Quick Stats Section -->
                <div class="row mt-4">
                    <div class="col-md-4 mb-3">
                        <div class="stat-card card h-100 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title text-teal">
                                    <i class="fas fa-clock mr-2"></i>Prochaine prise
                                </h5>
                                <p class="card-text display-4">
                                    <?php if (!empty($medicaments)): ?>
                                        <?= date('H:i', strtotime($medicaments[0]['prochaine_prise'])) ?>
                                    <?php else: ?>
                                        <span class="text-muted">Aucune</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <div class="stat-card card h-100 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title text-teal">
                                    <i class="fas fa-pills mr-2"></i>Médicaments
                                </h5>
                                <p class="card-text display-4">
                                    <?= count($medicaments) ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4 mb-3">
                        <div class="stat-card card h-100 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title text-teal">
                                    <i class="fas fa-phone-alt mr-2"></i>Urgences
                                </h5>
                                <a href="tel:15" class="btn btn-danger">
                                    <i class="fas fa-phone-alt"></i> Appeler le 15
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>