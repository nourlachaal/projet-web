<?php
require_once 'config.php';
require_once 'header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate inputs
        $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $position = filter_input(INPUT_POST, 'position', FILTER_SANITIZE_STRING);
        $testimonial = filter_input(INPUT_POST, 'testimonial', FILTER_SANITIZE_STRING);

        if (empty($name) || empty($email) || empty($testimonial)) {
            $_SESSION['testimonial_message'] = "Tous les champs obligatoires doivent être remplis.";
            $_SESSION['message_type'] = 'danger';
            header("Location: ".$_SERVER['HTTP_REFERER']."#testimonial-form");
            exit();
        }

        // Insert testimonial (no approval needed)
        $stmt = $pdo->prepare("INSERT INTO testimonials (name, email, position, testimonial) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $email, $position, $testimonial]);
        
        $_SESSION['testimonial_message'] = "Merci pour votre témoignage! Il est maintenant visible.";
        $_SESSION['message_type'] = 'success';
        header("Location: ".$_SERVER['HTTP_REFERER']."#testimonial-form");
        exit();

    } catch (PDOException $e) {
        $_SESSION['testimonial_message'] = "Erreur: ".$e->getMessage();
        $_SESSION['message_type'] = 'danger';
        header("Location: ".$_SERVER['HTTP_REFERER']."#testimonial-form");
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}
?>