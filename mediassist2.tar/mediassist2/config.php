<?php
// Remove ANY whitespace before <?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'mediassist2');
define('DB_USER', 'root'); 
define('DB_PASS', '');

define('SITE_NAME', 'Mediassit2');
define('SITE_URL', 'http://localhost/mediassist');

// Add this check for sessions
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

function redirect($url) {
    if (ob_get_length()) ob_clean();
    header("Location: $url");
    exit();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}