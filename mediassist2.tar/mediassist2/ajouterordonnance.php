<?php
$page_title = "Ajouter Ordonnance - MediAssit";
require_once 'config.php';
require_once 'header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doctor = trim($_POST['doctor_name']);
    $date = $_POST['date'];
    $medications = [];
    
    // Récupérer les médicaments
    foreach ($_POST['medications'] as $med) {
        if (!empty($med['name'])) {
            $medications[] = [
                'name' => htmlspecialchars($med['name']),
                'dosage' => htmlspecialchars($med['dosage'])
            ];
        }
    }
    
    // Validation
    if (empty($doctor)) {
        $errors[] = "Le nom du médecin est requis";
    }
    
    if (empty($medications)) {
        $errors[] = "Au moins un médicament est requis";
    }
    
    // Gestion de l'image
    $imagePath = null;
    if (isset($_FILES['ordonnance_image']) && $_FILES['ordonnance_image']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($_FILES['ordonnance_image']['type'], $allowedTypes)) {
            $errors[] = "Type de fichier non supporté (JPEG, PNG, GIF seulement)";
        } elseif ($_FILES['ordonnance_image']['size'] > $maxSize) {
            $errors[] = "Fichier trop volumineux (max 5MB)";
        } else {
            $uploadDir = 'uploads/ordonnances/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $extension = pathinfo($_FILES['ordonnance_image']['name'], PATHINFO_EXTENSION);
            $filename = uniqid().'.'.$extension;
            $destination = $uploadDir.$filename;
            
            if (move_uploaded_file($_FILES['ordonnance_image']['tmp_name'], $destination)) {
                $imagePath = $destination;
            } else {
                $errors[] = "Erreur lors de l'enregistrement du fichier";
            }
        }
    }
    
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO ordonnances 
                                  (user_id, doctor_name, date, medications, image_path) 
                                  VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $_SESSION['user_id'],
                $doctor,
                $date,
                json_encode($medications),
                $imagePath
            ]);
            
            $_SESSION['flash_message'] = "Ordonnance ajoutée avec succès";
            $_SESSION['flash_type'] = "success";
            redirect('ordonnances.php');
        } catch (PDOException $e) {
            $errors[] = "Erreur technique: ".$e->getMessage();
        }
    }
}
?>

<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card shadow">
                    <div class="card-header bg-teal text-white">
                        <h4 class="mb-0"><i class="fas fa-file-medical"></i> Ajouter une ordonnance</h4>
                    </div>
                    
                    <div class="card-body">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <?php foreach ($errors as $err): ?>
                                    <p class="mb-1"><?= $err ?></p>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="doctor_name">Médecin prescripteur *</label>
                                <input type="text" class="form-control" id="doctor_name" name="doctor_name" required
                                       value="<?= htmlspecialchars($_POST['doctor_name'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="date">Date de prescription *</label>
                                <input type="date" class="form-control" id="date" name="date" required
                                       value="<?= htmlspecialchars($_POST['date'] ?? date('Y-m-d')) ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Médicaments prescrits *</label>
                                <div id="medications-container">
                                    <div class="medication-item row mb-2">
                                        <div class="col-md-5">
                                            <input type="text" name="medications[0][name]" class="form-control" placeholder="Nom" required>
                                        </div>
                                        <div class="col-md-5">
                                            <input type="text" name="medications[0][dosage]" class="form-control" placeholder="Posologie" required>
                                        </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-danger remove-medication btn-block">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" id="add-medication" class="btn btn-outline-teal mt-2">
                                    <i class="fas fa-plus-circle"></i> Ajouter un médicament
                                </button>
                            </div>
                            
                            <div class="form-group">
                                <label for="ordonnance_image">Scan de l'ordonnance (optionnel)</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="ordonnance_image" name="ordonnance_image" accept="image/*">
                                    <label class="custom-file-label" for="ordonnance_image">Choisir un fichier...</label>
                                </div>
                                <small class="form-text text-muted">Formats acceptés: JPG, PNG, GIF (max 5MB)</small>
                            </div>
                            
                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-teal btn-lg btn-block">
                                    <i class="fas fa-save"></i> Enregistrer l'ordonnance
                                </button>
                                <a href="ordonnances.php" class="btn btn-outline-secondary btn-block mt-2">
                                    <i class="fas fa-arrow-left"></i> Annuler
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let medCount = 1;
    
    // Ajouter un médicament
    document.getElementById('add-medication').addEventListener('click', function() {
        const container = document.getElementById('medications-container');
        const newItem = document.createElement('div');
        newItem.className = 'medication-item row mb-2';
        newItem.innerHTML = `
            <div class="col-md-5">
                <input type="text" name="medications[${medCount}][name]" class="form-control" placeholder="Nom" required>
            </div>
            <div class="col-md-5">
                <input type="text" name="medications[${medCount}][dosage]" class="form-control" placeholder="Posologie" required>
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-danger remove-medication btn-block">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        container.appendChild(newItem);
        medCount++;
    });
    
    
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-medication') || 
            e.target.closest('.remove-medication')) {
            const item = e.target.closest('.medication-item');
            if (document.querySelectorAll('.medication-item').length > 1) {
                item.remove();
            } else {
                item.querySelectorAll('input').forEach(input => input.value = '');
            }
        }
    });
    
    // Affichage du nom du fichier
    document.querySelector('.custom-file-input').addEventListener('change', function(e) {
        const fileName = e.target.files[0]?.name || "Choisir un fichier...";
        e.target.nextElementSibling.textContent = fileName;
    });
});
</script>

<?php require_once 'footer.php'; ?>