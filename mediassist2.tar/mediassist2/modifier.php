<?php 
$pageTitle = "Modifier un médicament";
require_once 'config.php';
require_once 'header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

// Vérifier l'ID
if (!isset($_GET['id'])) {
    redirect('medicaments.php');
}

$medicament_id = $_GET['id'];

// Récupérer le médicament
$stmt = $pdo->prepare("SELECT * FROM medicaments WHERE id = ? AND user_id = ?");
$stmt->execute([$medicament_id, $_SESSION['user_id']]);
$medicament = $stmt->fetch();

if (!$medicament) {
    redirect('medicaments.php');
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom']);
    $posologie = trim($_POST['posologie']);
    $frequence = $_POST['frequence'];
    $heure_prise = $_POST['heure_prise'];
    $notes = trim($_POST['notes'] ?? '');
    
    // Mise à jour
    try {
        $stmt = $pdo->prepare("UPDATE medicaments 
                             SET nom = ?, posologie = ?, frequence = ?, 
                                 heure_prise = ?, notes = ?
                             WHERE id = ? AND user_id = ?");
        $stmt->execute([
            $nom,
            $posologie,
            $frequence,
            $heure_prise,
            $notes,
            $medicament_id,
            $_SESSION['user_id']
        ]);
        
        $_SESSION['flash'] = "Médicament mis à jour avec succès";
        redirect('medicaments.php');
    } catch (PDOException $e) {
        $error = "Erreur lors de la mise à jour";
    }
}
?>

<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card shadow-sm">
                    <div class="card-header bg-teal text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-edit"></i> Modifier le médicament
                        </h4>
                    </div>
                    
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger">
                                <?= htmlspecialchars($error) ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" class="medicament-form">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="nom">Nom du médicament*</label>
                                    <input type="text" class="form-control" id="nom" name="nom" 
                                           value="<?= htmlspecialchars($medicament['nom']) ?>" required>
                                </div>
                                
                                <div class="form-group col-md-6">
                                    <label for="frequence">Fréquence*</label>
                                    <select class="form-control" id="frequence" name="frequence" required>
                                        <option value="quotidien" <?= $medicament['frequence'] === 'quotidien' ? 'selected' : '' ?>>Quotidien</option>
                                        <option value="hebdomadaire" <?= $medicament['frequence'] === 'hebdomadaire' ? 'selected' : '' ?>>Hebdomadaire</option>
                                        <option value="mensuel" <?= $medicament['frequence'] === 'mensuel' ? 'selected' : '' ?>>Mensuel</option>
                                        <option value="ponctuel" <?= $medicament['frequence'] === 'ponctuel' ? 'selected' : '' ?>>Ponctuel</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="posologie">Posologie*</label>
                                <textarea class="form-control" id="posologie" name="posologie" rows="3" required><?= htmlspecialchars($medicament['posologie']) ?></textarea>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="heure_prise">Heure de prise*</label>
                                    <input type="time" class="form-control" id="heure_prise" name="heure_prise" 
                                           value="<?= substr($medicament['heure_prise'], 0, 5) ?>" required>
                                </div>
                                
                                <div class="form-group col-md-6">
                                    <label for="notes">Notes (optionnel)</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="2"><?= htmlspecialchars($medicament['notes']) ?></textarea>
                                </div>
                            </div>
                            
                            <div class="form-actions d-flex justify-content-between mt-4">
                                <a href="medicaments.php" class="btn btn-outline-secondary btn-lg">
                                    <i class="fas fa-arrow-left"></i> Annuler
                                </a>
                                <button type="submit" class="btn btn-teal btn-lg">
                                    <i class="fas fa-save"></i> Mettre à jour
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>