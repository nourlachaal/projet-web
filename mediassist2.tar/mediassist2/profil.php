<?php
$pageTitle = "Mon Profil - MediAssit";
require_once 'config.php';

// Redirection si non connecté
if (!isLoggedIn()) {
    redirect('login.php');
}

// Configuration du dossier de stockage
$upload_dir = 'uploads/profiles/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Récupération des données utilisateur
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $errors = [];
    
    // Validation des champs
    if (strlen($username) < 3) $errors[] = "Nom d'utilisateur trop court";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email invalide";
    
    // Traitement du mot de passe
    if (!empty($new_password)) {
        if (!password_verify($current_password, $user['password'])) {
            $errors[] = "Mot de passe actuel incorrect";
        } elseif (strlen($new_password) < 8) {
            $errors[] = "Le mot de passe doit contenir au moins 8 caractères";
        } elseif ($new_password !== $confirm_password) {
            $errors[] = "Les mots de passe ne correspondent pas";
        }
    }
    
    // Traitement de la photo de profil
    $profile_pic = $user['profile_pic'];
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['profile_picture'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 2 * 1024 * 1024; // 2MB
        
        // Vérification du fichier
        if (!in_array($file['type'], $allowed_types)) {
            $errors[] = "Type de fichier non supporté (JPEG, PNG, GIF seulement)";
        } elseif ($file['size'] > $max_size) {
            $errors[] = "Fichier trop volumineux (max 2MB)";
        } else {
            // Génération d'un nom de fichier unique
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'profile_'.$_SESSION['user_id'].'_'.time().'.'.$ext;
            $destination = $upload_dir.$filename;
            
            // Déplacement du fichier
            if (move_uploaded_file($file['tmp_name'], $destination)) {
                // Suppression de l'ancienne image
                if ($profile_pic && file_exists($upload_dir.$profile_pic)) {
                    unlink($upload_dir.$profile_pic);
                }
                $profile_pic = $filename;
            } else {
                $errors[] = "Erreur lors du téléchargement de l'image";
            }
        }
    }
    
    // Mise à jour si aucune erreur
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            $update_data = [
                'username' => $username,
                'email' => $email,
                'profile_pic' => $profile_pic,
                'id' => $_SESSION['user_id']
            ];
            
            $sql = "UPDATE users SET username = :username, email = :email, profile_pic = :profile_pic";
            
            if (!empty($new_password)) {
                $sql .= ", password = :password";
                $update_data['password'] = password_hash($new_password, PASSWORD_DEFAULT);
            }
            
            $sql .= " WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($update_data);
            
            $pdo->commit();
            
            // Mise à jour de la session
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            
            $success = "Profil mis à jour avec succès";
            $user = $update_data; // Mise à jour des données affichées
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Erreur lors de la mise à jour: ".$e->getMessage();
        }
    }
}

require_once 'header.php';
?>

<section class="profile_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="profile_sidebar">
                    <div class="profile_picture text-center">
                        <img id="profile_preview" 
                             src="<?= $user['profile_pic'] ? htmlspecialchars($upload_dir.$user['profile_pic']) : 'images/profile-placeholder.png' ?>" 
                             alt="Photo de profil" 
                             class="img-fluid rounded-circle mb-3" 
                             style="width: 150px; height: 150px; object-fit: cover;">
                        <input type="file" name="profile_picture" id="profile_picture" accept="image/*" class="d-none">
                        <button type="button" class="btn btn-outline-primary btn-sm" onclick="document.getElementById('profile_picture').click()">
                            <i class="fa fa-camera"></i> Changer la photo
                        </button>
                        <small class="d-block text-muted mt-1">JPEG, PNG ou GIF (max 2MB)</small>
                    </div>
                    <div class="profile_links mt-4">
                        <a href="ordonnances.php" class="d-block my-2">
                            <i class="fa fa-file-prescription"></i> Mes ordonnances
                        </a>
                        <a href="listesrendezvous.php" class="d-block my-2">
                            <i class="fa fa-calendar-check"></i> Mes rendez-vous
                        </a>
                        <a href="medicaments.php" class="d-block my-2">
                            <i class="fa fa-pills"></i> Mes médicaments
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="profile_content">
                    <h2><i class="fa fa-user"></i> Mon Profil</h2>
                    
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>
                    
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error): ?>
                                <p><?= htmlspecialchars($error) ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="username">Nom d'utilisateur</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?= htmlspecialchars($user['username']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?= htmlspecialchars($user['email']) ?>" required>
                        </div>
                        
                        <h4 class="mt-4">Changer le mot de passe</h4>
                        <div class="form-group">
                            <label for="current_password">Mot de passe actuel</label>
                            <input type="password" class="form-control" id="current_password" name="current_password">
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">Nouveau mot de passe</label>
                            <input type="password" class="form-control" id="new_password" name="new_password">
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirmer le nouveau mot de passe</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>
                        
                        <div class="form-group mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save"></i> Enregistrer les modifications
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
// Prévisualisation de l'image
document.getElementById('profile_picture').addEventListener('change', function(e) {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('profile_preview').src = e.target.result;
        }
        reader.readAsDataURL(file);
    }
});
</script>

<?php require_once 'footer.php'; ?>