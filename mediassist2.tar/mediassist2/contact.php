<?php
// Set page title
$page_title = "Contact Us - MediAssit";

// Include configuration and header
require_once 'config.php';
require_once 'header.php';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    // Toujours afficher un message de succès sans vérification
    $_SESSION['contact_status'] = [
        'type' => 'success',
        'message' => "Your message has been sent successfully! We'll get back to you soon."
    ];
    
    // Redirection pour éviter la resoumission du formulaire
    header("Location: contact.php");
    exit();
}

// Display flash messages if they exist
if (isset($_SESSION['contact_status'])) {
    $status = $_SESSION['contact_status'];
    ?>
    <div class="container mt-3">
        <div class="alert alert-<?= $status['type'] ?> alert-dismissible fade show" role="alert">
            <?= $status['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
    <?php
    unset($_SESSION['contact_status']);
}
?>

<!-- contact section -->
<section class="contact_section layout_padding-bottom">
    <div class="container">
        <div class="heading_container">
            <h2>Contact Us</h2>
        </div>
        
        <div class="row">
            <div class="col-md-7">
                <div class="form_container">
                    <form action="contact.php" method="POST">
                        <div>
                            <input type="text" name="name" placeholder="Full Name" value="<?= isset($name) ? htmlspecialchars($name) : '' ?>" />
                        </div>
                        <div>
                            <input type="email" name="email" placeholder="Email" value="<?= isset($email) ? htmlspecialchars($email) : '' ?>" />
                        </div>
                        <div>
                            <input type="text" name="phone" placeholder="Phone Number" value="<?= isset($phone) ? htmlspecialchars($phone) : '' ?>" />
                        </div>
                        <div>
                            <textarea class="message-box" name="message" placeholder="Message"><?= isset($message) ? htmlspecialchars($message) : '' ?></textarea>
                        </div>
                        <div class="btn_box">
                            <button type="submit" class="btn btn-primary">SEND MESSAGE</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-5">
                <div class="img-box">
                    <img src="images/contact-img.jpg" alt="Contact Us">
                </div>
                <div class="contact-info mt-4">
                    <h4>Contact Information</h4>
                    <p><i class="fa fa-phone"></i> +01 123455678990</p>
                    <p><i class="fa fa-envelope"></i> demo@gmail.com</p>
                    <p><i class="fa fa-map-marker"></i> 123 Medical Street, Health City</p>
                    <h4 class="mt-3">Opening Hours</h4>
                    <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p>Saturday: 9:00 AM - 3:00 PM</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end contact section -->

<?php
// Include footer
require_once 'footer.php';
?>