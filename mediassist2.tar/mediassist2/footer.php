        <!-- info section -->
        <section class="info_section">
            <div class="container">
                <div class="info_top">
                    <div class="info_logo">
                        <a href="">
                            <img src="images/logo4.png" alt="" />
                        </a>
                    </div>
                    <div class="info_form">
                        <form action="">
                            <input type="email" placeholder="Your email" />
                            <button>Subscribe</button>
                        </form>
                    </div>
                </div>
                <div class="info_bottom layout_padding2">
                    <div class="row info_main_row">
                        <div class="col-md-6 col-lg-3">
                            <h5>Address</h5>
                            <div class="info_contact">
                                <a href="">
                                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                                    <span> Location </span>
                                </a>
                                <a href="">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                    <span> Call +01 1234567890 </span>
                                </a>
                                <a href="">
                                    <i class="fa fa-envelope"></i>
                                    <span> demo@gmail.com </span>
                                </a>
                            </div>
                            <div class="social_box">
                                <a href="">
                                    <i class="fa fa-facebook" aria-hidden="true"></i>
                                </a>
                                <a href="">
                                    <i class="fa fa-twitter" aria-hidden="true"></i>
                                </a>
                                <a href="">
                                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                                </a>
                                <a href="">
                                    <i class="fa fa-instagram" aria-hidden="true"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="info_links">
                                <h5>Map</h5>
                                <div class="info_links_menu">
                                    <a class="active" href="index.php"> Home </a>
                                    <a href="about.php"> About </a>
                                    <a href="medicaments.php"> Medicaments </a>
                                    <a href="ordonances.php"> Ordonnances </a>
                                    <a href="rendezvous.php"> Rendez vous </a>
                                    <a href="contact.php"> Contact us </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="info_post">
                                <h5>Helpful medical sites</h5>
                                <div class="post_box">
                                    <div class="img-box">
                                        <img src="images/unnamed.png" alt="" />
                                    </div>
                                    <p>WebMd</p>
                                </div>
                                <div class="post_box">
                                    <div class="img-box">
                                        <img src="images/mayo.jpg" alt="" />
                                    </div>
                                    <p>Mayo Clinic</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="info_post">
                                <h5>News</h5>
                                <div class="post_box">
                                    <div class="img-box">
                                        <img src="images/drugs.jpg" alt="" />
                                    </div>
                                    <p>Ordering illicit weight loss drugs is 'dicing with death' - GP</p>
                                </div>
                                <div class="post_box">
                                    <div class="img-box">
                                        <img src="images/depression.jpg" alt="" />
                                    </div>
                                    <p>Troubling Trend: US Depression Rates Climb While Treatment Lags</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end info_section -->

        <!-- footer section -->
        <footer class="footer_section">
            <div class="container">
                <p>
                    &copy; <span id="displayYear"></span> All Rights Reserved By
                    <a href="<?php echo SITE_URL; ?>"><?php echo SITE_NAME; ?></a>
                </p>
            </div>
        </footer>
        <!-- footer section -->

        <!-- jQery -->
        <script src="js/jquery-3.4.1.min.js"></script>
        <!-- bootstrap js -->
        <script src="js/bootstrap.js"></script>
        <!-- nice select -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js" integrity="sha256-Zr3vByTlMGQhvMfgkQ5BtWRSKBGa2QlspKYJnkjZTmo=" crossorigin="anonymous"></script>
        <!-- owl slider -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
        <!-- datepicker -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
        <!-- custom js -->
        <script src="js/custom.js"></script>
    </body>
</html>