<?php
require_once 'config.php';
require_once 'header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

if (!isset($_GET['id'])) {
    $_SESSION['flash_message'] = "Ordonnance non spécifiée";
    $_SESSION['flash_type'] = "danger";
    redirect('ordonnances.php');
}

$ordonnance_id = $_GET['id'];
$stmt = $pdo->prepare("SELECT image_path FROM ordonnances WHERE id = ? AND user_id = ?");
$stmt->execute([$ordonnance_id, $_SESSION['user_id']]);
$ordonnance = $stmt->fetch();

if (!$ordonnance) {
    $_SESSION['flash_message'] = "Ordonnance non trouvée";
    $_SESSION['flash_type'] = "danger";
    redirect('ordonnances.php');
}

try {
    // Suppression de l'image si elle existe
    if ($ordonnance['image_path'] && file_exists($ordonnance['image_path'])) {
        unlink($ordonnance['image_path']);
    }

    // Suppression de la base de données
    $pdo->prepare("DELETE FROM ordonnances WHERE id = ?")->execute([$ordonnance_id]);
    
    $_SESSION['flash_message'] = "Ordonnance supprimée avec succès";
    $_SESSION['flash_type'] = "success";
} catch (PDOException $e) {
    $_SESSION['flash_message'] = "Erreur lors de la suppression: " . $e->getMessage();
    $_SESSION['flash_type'] = "danger";
}

redirect('ordonnances.php');
?>