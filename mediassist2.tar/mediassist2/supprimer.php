<?php
require_once 'config.php';
require_once 'header.php';

// Verify user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Verify ID parameter
if (!isset($_GET['id'])) {
    redirect('medicaments.php');
}

$medicament_id = $_GET['id'];

// Verify medication exists and belongs to user
$stmt = $pdo->prepare("SELECT id FROM medicaments WHERE id = ? AND user_id = ?");
$stmt->execute([$medicament_id, $_SESSION['user_id']]);
$medicament = $stmt->fetch();

if (!$medicament) {
    $_SESSION['error'] = "Médicament non trouvé ou vous n'avez pas les droits";
    redirect('medicaments.php');
}

// Handle deletion
try {
    $stmt = $pdo->prepare("DELETE FROM medicaments WHERE id = ? AND user_id = ?");
    $stmt->execute([$medicament_id, $_SESSION['user_id']]);
    
    $_SESSION['flash'] = "Médicament supprimé avec succès";
} catch (PDOException $e) {
    $_SESSION['error'] = "Erreur lors de la suppression: " . $e->getMessage();
}

redirect('medicaments.php');
?>