<?php 
$pageTitle = "Ajouter un médicament";
require_once 'config.php';
require_once 'header.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom']);
    $posologie = trim($_POST['posologie']);
    $frequence = $_POST['frequence'];
    $heure_prise = $_POST['heure_prise'];
    $notes = trim($_POST['notes'] ?? '');
    
    // Validation des données
    if (empty($nom) || empty($posologie) || empty($heure_prise)) {
        $error = "Veuillez remplir tous les champs obligatoires";
    } else {
        // Calcul de la prochaine prise
        $prochaine_prise = date('Y-m-d') . ' ' . $heure_prise;
        if (time() > strtotime($prochaine_prise)) {
            $prochaine_prise = date('Y-m-d', strtotime('+1 day')) . ' ' . $heure_prise;
        }
        
        try {
            $stmt = $pdo->prepare("INSERT INTO medicaments 
                                 (user_id, nom, posologie, frequence, heure_prise, prochaine_prise, notes) 
                                 VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $_SESSION['user_id'],
                $nom,
                $posologie,
                $frequence,  // Correction: 'frequence' au lieu de 'frequence'
                $heure_prise,
                $prochaine_prise,
                $notes
            ]);
            
            $_SESSION['flash'] = "Médicament ajouté avec succès";
            redirect('medicaments.php');
        } catch (PDOException $e) {
            error_log("Erreur d'ajout de médicament: " . $e->getMessage());
            $error = "Erreur lors de l'ajout du médicament: " . $e->getMessage();
        }
    }
}
?>

<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card shadow-sm">
                    <div class="card-header bg-teal text-white">
                        <h4 class="mb-0">
                            <i class="fas fa-plus-circle"></i> Ajouter un nouveau médicament
                        </h4>
                    </div>
                    
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger">
                                <?= htmlspecialchars($error) ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" class="medicament-form">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="nom">Nom du médicament*</label>
                                    <input type="text" class="form-control" id="nom" name="nom" required
                                           value="<?= isset($_POST['nom']) ? htmlspecialchars($_POST['nom']) : '' ?>">
                                </div>
                                
                                <div class="form-group col-md-6">
                                    <label for="frequence">Fréquence*</label>
                                    <select class="form-control" id="frequence" name="frequence" required>
                                        <option value="quotidien" <?= (isset($_POST['frequence']) && $_POST['frequence'] === 'quotidien') ? 'selected' : '' ?>>Quotidien</option>
                                        <option value="hebdomadaire" <?= (isset($_POST['frequence']) && $_POST['frequence'] === 'hebdomadaire') ? 'selected' : '' ?>>Hebdomadaire</option>
                                        <option value="mensuel" <?= (isset($_POST['frequence']) && $_POST['frequence'] === 'mensuel') ? 'selected' : '' ?>>Mensuel</option>
                                        <option value="ponctuel" <?= (isset($_POST['frequence']) && $_POST['frequence'] === 'ponctuel') ? 'selected' : '' ?>>Ponctuel</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="posologie">Posologie*</label>
                                <textarea class="form-control" id="posologie" name="posologie" rows="3" required><?= isset($_POST['posologie']) ? htmlspecialchars($_POST['posologie']) : '' ?></textarea>
                                <small class="text-muted">Ex: 1 comprimé matin et soir</small>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="heure_prise">Heure de prise*</label>
                                    <input type="time" class="form-control" id="heure_prise" name="heure_prise" 
                                           value="<?= isset($_POST['heure_prise']) ? htmlspecialchars($_POST['heure_prise']) : '' ?>" required>
                                </div>
                                
                                <div class="form-group col-md-6">
                                    <label for="notes">Notes (optionnel)</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="2"><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?></textarea>
                                </div>
                            </div>
                            
                            <div class="form-actions d-flex justify-content-between mt-4">
                                <a href="medicaments.php" class="btn btn-outline-secondary btn-lg">
                                    <i class="fas fa-arrow-left"></i> Annuler
                                </a>
                                <button type="submit" class="btn btn-teal btn-lg">
                                    <i class="fas fa-save"></i> Enregistrer
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>