<?php
$page_title = "About Us - MediAssit";
require_once 'config.php';
require_once 'header.php';
?>

<section class="slider_section">
    <div class="dot_design">
        <img src="images/dots.png" alt="" />
    </div>
    <div id="customCarousel1" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-box">
                                <div class="play_btn">
                                    <button>
                                        <i class="fa fa-play" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <h1>
                                    Medi <br />
                                    <span> Assist </span>
                                </h1>
                                <p>
                                    Mediassit est une plateforme en ligne dédiée à
                                    simplifier la gestion des soins médicaux pour les
                                    patients
                                </p>
                                <a href="contact.php"> Contact Us </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="img-box">
                                <img src="images/slider-img.jpg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-box">
                                <div class="play_btn">
                                    <button>
                                        <i class="fa fa-play" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <h1>
                                    Medi <br />
                                    <span> Assist </span>
                                </h1>
                                <p>
                                    Grâce à notre interface intuitive, les clients peuvent :
                                    Prendre rendez-vous avec des professionnels de santé en
                                    quelques clics. Consulter et enregistrer leurs
                                    médicaments et ordonnances numériquement. Nous contacter
                                    rapidement en cas d'urgence ou pour des demandes
                                    urgentes.
                                </p>
                                <a href="contact.php"> Contact Us </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="img-box">
                                <img src="images/slider-img.jpg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-box">
                                <div class="play_btn">
                                    <button>
                                        <i class="fa fa-play" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <h1>
                                    Medi<br />
                                    <span> Assist </span>
                                </h1>
                                <p>
                                    Conçu pour la sécurité et l'accessibilité, Mediassit
                                    offre un suivi médical organisé, réduisant les temps
                                    d'attente et centralisant les informations essentielles.
                                </p>
                                <a href="contact.php"> Contact Us </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="img-box">
                                <img src="images/slider-img.jpg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="carousel_btn-box">
            <a class="carousel-control-prev" href="#customCarousel1" role="button" data-slide="prev">
                <img src="images/prev.png" alt="Previous" class="custom-carousel-control">
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#customCarousel1" role="button" data-slide="next">
                <img src="images/next.png" alt="Next" class="custom-carousel-control">
                <span class="sr-only">Next</span>
          </a>
        </div>
    </div>
</section>

<?php
require_once 'footer.php';
?>