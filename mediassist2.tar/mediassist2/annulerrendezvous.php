<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM rendezvous WHERE id = ? AND user_id = ?");
        $stmt->execute([$_GET['id'], $_SESSION['user_id']]);
        
        $_SESSION['success'] = "Rendez-vous annulé avec succès";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur lors de l'annulation: " . $e->getMessage();
    }
}

// Redirection absolue recommandée
$redirect_url = dirname($_SERVER['PHP_SELF']) . '/listesrendezvous.php';
header("Location: " . $redirect_url);
exit();
?>