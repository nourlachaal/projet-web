<?php
// Set page title
$page_title = "Prendre Rendez-vous - MediAssit";

// Include configuration and header
require_once 'config.php';
require_once 'header.php';

// Verify user is logged in
if (!isLoggedIn()) {
    $_SESSION['error'] = "Vous devez vous connecter pour accéder à cette page";
    header("Location: login.php");
    exit();
}

// Traitement du formulaire de rendez-vous
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $userId = $_POST['user_id'];
    $typeConsultation = $_POST['type_consultation'];
    $dateHeure = $_POST['date_heure'];
    $lieu = $_POST['lieu'] ?? null;
    $notes = $_POST['notes'] ?? null;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO rendezvous (user_id, type_consultation, date_heure, lieu, notes) 
                              VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $typeConsultation, $dateHeure, $lieu, $notes]);
        
        $_SESSION['success'] = "Rendez-vous pris avec succès!";
        header("Location: listesrendezvous.php");
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur lors de la prise de rendez-vous: " . $e->getMessage();
    }
}
?>

<!-- Appointment Booking Section -->
<section class="book_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col">
                <form action="rendezvous.php" method="POST">
                    <h4>PRENDRE <span>UN RENDEZ-VOUS</span></h4>
                    <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>">
                    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="type_consultation">Type de consultation</label>
                            <select class="form-control" id="type_consultation" name="type_consultation" required>
                                <option value="">Sélectionnez un type</option>
                                <option value="Consultation générale">Consultation générale</option>
                                <option value="Suivi de traitement">Suivi de traitement</option>
                                <option value="Urgence">Urgence</option>
                                <option value="Vaccination">Vaccination</option>
                                <option value="Examen médical">Examen médical</option>
                            </select>
                        </div>
                        
                        <div class="form-group col-md-6">
                            <label for="date_heure">Date et heure</label>
                            <input type="datetime-local" class="form-control" id="date_heure" name="date_heure" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="lieu">Lieu (optionnel)</label>
                        <input type="text" class="form-control" id="lieu" name="lieu" placeholder="Adresse ou cabinet médical">
                    </div>
                    
                    <div class="form-group">
                        <label for="notes">Notes (optionnel)</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Décrivez brièvement vos symptômes ou besoins"></textarea>
                    </div>
                    
                    <div class="btn-box d-flex gap-2">
                        <button type="submit" class="btn btn-success">Soumettre</button>
                        <a href="listesrendezvous.php" class="btn btn-teal">Voir mes rendez-vous</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php
// Include footer
require_once 'footer.php';
?>