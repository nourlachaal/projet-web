<?php
$page_title = "Accueil - MediAssit";
require_once 'config.php';
require_once 'header.php';
?>

<!-- Hero and Slider Section -->
<section class="slider_section">
    <div class="dot_design">
        <img src="images/dots.png" alt="" />
    </div>
    <div id="customCarousel1" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-box">
                                <div class="play_btn">
                                    <button>
                                        <i class="fa fa-play" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <h1>
                                    Medi <br />
                                    <span> Assist </span>
                                </h1>
                                <p>
                                    Mediassit est une plateforme en ligne dédiée à
                                    simplifier la gestion des soins médicaux pour les
                                    patients
                                </p>
                                <a href="contact.php"> Contact Us </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="img-box">
                                <img src="images/slider-img.jpg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-box">
                                <div class="play_btn">
                                    <button>
                                        <i class="fa fa-play" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <h1>
                                    Medi <br />
                                    <span> Assist </span>
                                </h1>
                                <p>
                                    Grâce à notre interface intuitive, les clients peuvent :
                                    Prendre rendez-vous avec des professionnels de santé en
                                    quelques clics. Consulter et enregistrer leurs
                                    médicaments et ordonnances numériquement. Nous contacter
                                    rapidement en cas d'urgence ou pour des demandes
                                    urgentes.
                                </p>
                                <a href="contact.php"> Contact Us </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="img-box">
                                <img src="images/slider-img.jpg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-box">
                                <div class="play_btn">
                                    <button>
                                        <i class="fa fa-play" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <h1>
                                    Medi<br />
                                    <span> Assist </span>
                                </h1>
                                <p>
                                    Conçu pour la sécurité et l'accessibilité, Mediassit
                                    offre un suivi médical organisé, réduisant les temps
                                    d'attente et centralisant les informations essentielles.
                                </p>
                                <a href="contact.php"> Contact Us </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="img-box">
                                <img src="images/slider-img.jpg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="carousel_btn-box">
            <a class="carousel-control-prev" href="#customCarousel1" role="button" data-slide="prev">
                <img src="images/prev.png" alt="" />
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#customCarousel1" role="button" data-slide="next">
                <img src="images/next.png" alt="" />
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="about_section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="img-box">
                    <img src="images/about-img.jpg" alt="À propos de MediAssit" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="detail-box">
                    <div class="heading_container">
                        <h2>À propos de <span>MediAssit</span></h2>
                    </div>
                    <p>
                        MediAssit est une plateforme innovante dédiée à la gestion simplifiée des soins médicaux.
                        Notre mission est de faciliter la prise de rendez-vous médicaux, le suivi des ordonnances
                        et la communication entre patients et professionnels de santé.
                    </p>
                    <p>
                        Avec une interface intuitive et sécurisée, nous réduisons les temps d'attente et centralisons
                        toutes les informations médicales essentielles au même endroit.
                    </p>
                    <a href="about.php"> En savoir plus </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="treatment_section layout_padding">
    <div class="side_img">
        <img src="images/treatment-side-img.jpg" alt="" />
    </div>
    <div class="container">
        <div class="heading_container heading_center">
            <h2>Nos <span>Services</span></h2>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="box">
                    <div class="img-box">
                        <img src="images/t1.png" alt="Gestion de rendez-vous" />
                    </div>
                    <div class="detail-box">
                        <h4>Rendez-vous médicaux</h4>
                        <p>
                            Prenez rendez-vous en ligne avec des professionnels de santé
                            en quelques clics, 24h/24 et 7j/7.
                        </p>
                        <a href="rendezvous.php"> En savoir plus </a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="box">
                    <div class="img-box">
                        <img src="images/t2.png" alt="Gestion d'ordonnances" />
                    </div>
                    <div class="detail-box">
                        <h4>Ordonnances</h4>
                        <p>
                            Conservez et gérez toutes vos ordonnances médicales
                            au même endroit, accessible à tout moment.
                        </p>
                        <a href="ordonnances.php"> En savoir plus </a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="box">
                    <div class="img-box">
                        <img src="images/t3.png" alt="Gestion de médicaments" />
                    </div>
                    <div class="detail-box">
                        <h4>Médicaments</h4>
                        <p>
                            Suivez vos traitements médicaux et recevez des alertes
                            pour ne pas oublier de prendre vos médicaments.
                        </p>
                        <a href="medicaments.php"> En savoir plus </a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="box">
                    <div class="img-box">
                        <img src="images/t4.png" alt="Urgences" />
                    </div>
                    <div class="detail-box">
                        <h4>Urgences</h4>
                        <p>
                            Contactez rapidement un professionnel en cas d'urgence
                            ou pour des demandes médicales urgentes.
                        </p>
                        <a href="contact.php"> En savoir plus </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Testimonial Submission Form -->
<section class="testimonial_form layout_padding">
    <div class="container">
        <div class="heading_container">
            <h2><span>Laissez votre avis</span></h2>
        </div>
        
        <?php if(isset($_SESSION['testimonial_message'])): ?>
            <div class="alert alert-<?= $_SESSION['message_type'] ?>">
                <?= $_SESSION['testimonial_message'] ?>
            </div>
            <?php 
            unset($_SESSION['testimonial_message']);
            unset($_SESSION['message_type']);
            ?>
        <?php endif; ?>
        
        <form action="submitcom.php" method="POST">
            <div class="form-group">
                <label for="name">Nom complet *</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email *</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="position">Fonction/Rôle (optionnel)</label>
                <input type="text" class="form-control" id="position" name="position">
            </div>
            <div class="form-group">
                <label for="testimonial">Votre témoignage *</label>
                <textarea class="form-control" id="testimonial" name="testimonial" rows="5" required></textarea>
            </div>
            <div class="btn_box">
                            <button type="submit">ENVOYER</button>
                        </div>
        </form>
    </div>
</section>

<!-- Testimonials Display Section -->
<section class="client_section layout_padding">
    <div class="container">
        <div class="heading_container">
            <h2><span>Témoignages</span></h2>
        </div>
    </div>
    <div class="container px-0">
        <div id="customCarousel2" class="carousel carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
                <?php
                try {
                    $stmt = $pdo->query("SELECT * FROM testimonials ORDER BY date DESC LIMIT 3");
                    $first = true;
                    while ($row = $stmt->fetch()) {
                        echo '
                        <div class="carousel-item '.($first ? 'active' : '').'">
                            <div class="box">
                                <div class="client_info">
                                    <div class="client_name">
                                        <h5>'.htmlspecialchars($row['name']).'</h5>
                                        <h6>'.htmlspecialchars($row['position']).'</h6>
                                    </div>
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                                </div>
                                <p>'.htmlspecialchars($row['testimonial']).'</p>
                            </div>
                        </div>';
                        $first = false;
                    }
                    
                    if ($first) {
                        echo '<div class="carousel-item active">
                                <div class="box">
                                    <p>Soyez le premier à laisser un témoignage!</p>
                                </div>
                            </div>';
                    }
                } catch (PDOException $e) {
                    echo '<div class="carousel-item active">
                            <div class="box">
                                <p>Impossible de charger les témoignages</p>
                            </div>
                        </div>';
                }
                ?>
            </div>
            <div class="carousel_btn-box">
                <a class="carousel-control-prev" href="#customCarousel2" role="button" data-slide="prev">
                    <i class="fa fa-angle-left" aria-hidden="true"></i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#customCarousel2" role="button" data-slide="next">
                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</section>
<?php
// Include footer
require_once 'footer.php';
?>