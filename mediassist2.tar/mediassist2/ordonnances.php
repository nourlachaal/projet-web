<?php
$page_title = "Mes Ordonnances - MediAssit";
require_once 'config.php';
require_once 'header.php';

if (!isLoggedIn()) {
    $_SESSION['flash_message'] = "Vous devez vous connecter";
    $_SESSION['flash_type'] = "warning";
    redirect('login.php');
}

// Gestion de la suppression
if (isset($_GET['supprimer'])) {
    $ordonnance_id = $_GET['supprimer'];
    
    // Vérifier que l'ordonnance appartient à l'utilisateur
    $stmt = $pdo->prepare("SELECT image_path FROM ordonnances WHERE id = ? AND user_id = ?");
    $stmt->execute([$ordonnance_id, $_SESSION['user_id']]);
    $ordonnance = $stmt->fetch();
    
    if ($ordonnance) {
        try {
            // Supprimer l'image si elle existe
            if ($ordonnance['image_path'] && file_exists($ordonnance['image_path'])) {
                unlink($ordonnance['image_path']);
            }
            
            // Supprimer de la base de données
            $pdo->prepare("DELETE FROM ordonnances WHERE id = ?")->execute([$ordonnance_id]);
            
            $_SESSION['flash_message'] = "Ordonnance supprimée avec succès";
            $_SESSION['flash_type'] = "success";
        } catch (PDOException $e) {
            $_SESSION['flash_message'] = "Erreur lors de la suppression";
            $_SESSION['flash_type'] = "danger";
        }
    }
    redirect('ordonnances.php');
}

// Récupérer les ordonnances
try {
    $stmt = $pdo->prepare("SELECT * FROM ordonnances WHERE user_id = ? ORDER BY date DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $ordonnances = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $error = "Erreur lors du chargement des ordonnances";
}
?>

<section class="layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="heading_container mb-4">
                    <h2><i class="fas fa-file-medical"></i> Mes Ordonnances</h2>
                    <a href="ajouterordonnance.php" class="btn btn-teal">
                        <i class="fas fa-plus"></i> Ajouter une ordonnance
                    </a>
                </div>

                <?php if (isset($_SESSION['flash_message'])): ?>
                    <div class="alert alert-<?= $_SESSION['flash_type'] ?>">
                        <?= $_SESSION['flash_message'] ?>
                    </div>
                    <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
                <?php endif; ?>

                <?php if (!empty($ordonnances)): ?>
                    <div class="card shadow-sm">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="login-form .btn-primary:hover">
                                        <tr>
                                            <th>Date</th>
                                            <th>Médecin</th>
                                            <th>Médicaments</th>
                                            <th>Scan</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($ordonnances as $ord): 
                                            $meds = json_decode($ord['medications'], true) ?: [];
                                        ?>
                                            <tr>
                                                <td><?= date('d/m/Y', strtotime($ord['date'])) ?></td>
                                                <td><?= htmlspecialchars($ord['doctor_name']) ?></td>
                                                <td><?php 
    $meds = json_decode($ord['medications'], true) ?: [];
    $medNames = array_column($meds, 'name');
    echo implode(', ', array_map('htmlspecialchars', $medNames));
    ?></td>
                                                <td>
                                                    <?php if ($ord['image_path']): ?>
                                                        <a href="<?= $ord['image_path'] ?>" target="_blank" class="btn btn-sm btn-outline-teal">
                                                            <i class="fas fa-eye"></i> Voir
                                                        </a>
                                                    <?php else: ?>
                                                        <span class="text-muted">Aucun scan</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="d-flex">
                                                        <a href="detailsordonnance.php?id=<?= $ord['id'] ?>" class="btn btn-sm btn-outline-teal mr-2">
                                                            <i class="fas fa-info-circle"></i> Détails
                                                        </a>
                                                        <a href="modifierordonnance.php?id=<?= $ord['id'] ?>" class="btn btn-sm btn-outline-primary mr-2">
                                                            <i class="fas fa-edit"></i> Modifier
                                                        </a>
                                                        <a href="ordonnances.php?supprimer=<?= $ord['id'] ?>" class="btn btn-sm btn-danger"
                                                           onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette ordonnance ?')">
                                                            <i class="fas fa-trash"></i> Supprimer
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="empty-state text-center py-5">
                        <i class="fas fa-file-medical fa-4x text-muted mb-4"></i>
                        <h4>Vous n'avez aucune ordonnance enregistrée</h4>
                        <p class="text-muted mb-4">Commencez par ajouter votre première ordonnance</p>
                        <a href="ajouterordonnance.php" class="btn btn-teal">
                            <i class="fas fa-plus"></i> Ajouter une ordonnance
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php require_once 'footer.php'; ?>